﻿
namespace DoAn.Net
{
    partial class QuanLyThe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(QuanLyThe));
            this.lsvt_DSDG = new System.Windows.Forms.ListView();
            this.maTheDG = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.MaDG = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tinhTrang = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ngayDangKy = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ngayHetHan = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.HoTen = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.NgaySinh = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.GioiTinh = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.DiaChi = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Email = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SDT = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.TenLDG = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.txt_NgaySinh = new System.Windows.Forms.TextBox();
            this.btn_InThe = new System.Windows.Forms.Button();
            this.buttonLichSuThe = new System.Windows.Forms.Button();
            this.txt_NgayHetHan = new System.Windows.Forms.TextBox();
            this.txt_NgayDK = new System.Windows.Forms.TextBox();
            this.txt_TinhTrang = new System.Windows.Forms.TextBox();
            this.txt_MaThe = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txt_TimKiem = new System.Windows.Forms.TextBox();
            this.cbo_TimKiem = new System.Windows.Forms.ComboBox();
            this.lb_Ketquatimkiem = new System.Windows.Forms.Label();
            this.btn_Search = new System.Windows.Forms.Button();
            this.txt_LoaiDG = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel = new System.Windows.Forms.Panel();
            this.txt_Email = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txt_SoDienThoai = new System.Windows.Forms.TextBox();
            this.txt_TenDayDu = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_Refesh = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lsvt_DSDG
            // 
            this.lsvt_DSDG.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.maTheDG,
            this.MaDG,
            this.tinhTrang,
            this.ngayDangKy,
            this.ngayHetHan,
            this.HoTen,
            this.NgaySinh,
            this.GioiTinh,
            this.DiaChi,
            this.Email,
            this.SDT,
            this.TenLDG});
            this.lsvt_DSDG.HideSelection = false;
            this.lsvt_DSDG.Location = new System.Drawing.Point(0, 15);
            this.lsvt_DSDG.Margin = new System.Windows.Forms.Padding(2);
            this.lsvt_DSDG.Name = "lsvt_DSDG";
            this.lsvt_DSDG.Size = new System.Drawing.Size(1253, 263);
            this.lsvt_DSDG.TabIndex = 12;
            this.lsvt_DSDG.UseCompatibleStateImageBehavior = false;
            this.lsvt_DSDG.View = System.Windows.Forms.View.Details;
            this.lsvt_DSDG.MouseClick += new System.Windows.Forms.MouseEventHandler(this.lsvt_DSDG_MouseClick);
            // 
            // maTheDG
            // 
            this.maTheDG.Text = "Mã thẻ";
            // 
            // MaDG
            // 
            this.MaDG.Text = "Mã độc giả";
            this.MaDG.Width = 81;
            // 
            // tinhTrang
            // 
            this.tinhTrang.Text = "Tình trạng";
            this.tinhTrang.Width = 117;
            // 
            // ngayDangKy
            // 
            this.ngayDangKy.Text = "Ngày đăng ký";
            this.ngayDangKy.Width = 115;
            // 
            // ngayHetHan
            // 
            this.ngayHetHan.Text = "Ngày hết hạn";
            this.ngayHetHan.Width = 128;
            // 
            // HoTen
            // 
            this.HoTen.Text = "Họ tên";
            this.HoTen.Width = 100;
            // 
            // NgaySinh
            // 
            this.NgaySinh.Text = "Ngày sinh";
            this.NgaySinh.Width = 86;
            // 
            // GioiTinh
            // 
            this.GioiTinh.Text = "Giới tính";
            this.GioiTinh.Width = 68;
            // 
            // DiaChi
            // 
            this.DiaChi.Text = "Địa chỉ";
            this.DiaChi.Width = 149;
            // 
            // Email
            // 
            this.Email.Text = "Email";
            this.Email.Width = 67;
            // 
            // SDT
            // 
            this.SDT.Text = "Số điện thoại";
            this.SDT.Width = 98;
            // 
            // TenLDG
            // 
            this.TenLDG.Text = "Loại độc giả";
            this.TenLDG.Width = 124;
            // 
            // txt_NgaySinh
            // 
            this.txt_NgaySinh.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_NgaySinh.Enabled = false;
            this.txt_NgaySinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.txt_NgaySinh.Location = new System.Drawing.Point(292, 55);
            this.txt_NgaySinh.Margin = new System.Windows.Forms.Padding(2);
            this.txt_NgaySinh.Name = "txt_NgaySinh";
            this.txt_NgaySinh.Size = new System.Drawing.Size(218, 27);
            this.txt_NgaySinh.TabIndex = 127;
            // 
            // btn_InThe
            // 
            this.btn_InThe.BackColor = System.Drawing.Color.Aqua;
            this.btn_InThe.Image = ((System.Drawing.Image)(resources.GetObject("btn_InThe.Image")));
            this.btn_InThe.Location = new System.Drawing.Point(901, 96);
            this.btn_InThe.Margin = new System.Windows.Forms.Padding(2);
            this.btn_InThe.Name = "btn_InThe";
            this.btn_InThe.Size = new System.Drawing.Size(131, 63);
            this.btn_InThe.TabIndex = 126;
            this.btn_InThe.UseVisualStyleBackColor = false;
            this.btn_InThe.Click += new System.EventHandler(this.btn_InThe_Click);
            // 
            // buttonLichSuThe
            // 
            this.buttonLichSuThe.BackColor = System.Drawing.Color.Aqua;
            this.buttonLichSuThe.Image = ((System.Drawing.Image)(resources.GetObject("buttonLichSuThe.Image")));
            this.buttonLichSuThe.Location = new System.Drawing.Point(901, 17);
            this.buttonLichSuThe.Margin = new System.Windows.Forms.Padding(2);
            this.buttonLichSuThe.Name = "buttonLichSuThe";
            this.buttonLichSuThe.Size = new System.Drawing.Size(131, 63);
            this.buttonLichSuThe.TabIndex = 125;
            this.buttonLichSuThe.UseVisualStyleBackColor = false;
            this.buttonLichSuThe.Click += new System.EventHandler(this.buttonLichSuThe_Click);
            // 
            // txt_NgayHetHan
            // 
            this.txt_NgayHetHan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_NgayHetHan.Enabled = false;
            this.txt_NgayHetHan.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.txt_NgayHetHan.Location = new System.Drawing.Point(664, 132);
            this.txt_NgayHetHan.Margin = new System.Windows.Forms.Padding(2);
            this.txt_NgayHetHan.Name = "txt_NgayHetHan";
            this.txt_NgayHetHan.Size = new System.Drawing.Size(218, 27);
            this.txt_NgayHetHan.TabIndex = 124;
            // 
            // txt_NgayDK
            // 
            this.txt_NgayDK.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_NgayDK.Enabled = false;
            this.txt_NgayDK.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.txt_NgayDK.Location = new System.Drawing.Point(664, 94);
            this.txt_NgayDK.Margin = new System.Windows.Forms.Padding(2);
            this.txt_NgayDK.Name = "txt_NgayDK";
            this.txt_NgayDK.Size = new System.Drawing.Size(218, 27);
            this.txt_NgayDK.TabIndex = 123;
            // 
            // txt_TinhTrang
            // 
            this.txt_TinhTrang.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_TinhTrang.Enabled = false;
            this.txt_TinhTrang.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.txt_TinhTrang.Location = new System.Drawing.Point(664, 55);
            this.txt_TinhTrang.Margin = new System.Windows.Forms.Padding(2);
            this.txt_TinhTrang.Name = "txt_TinhTrang";
            this.txt_TinhTrang.Size = new System.Drawing.Size(218, 27);
            this.txt_TinhTrang.TabIndex = 122;
            // 
            // txt_MaThe
            // 
            this.txt_MaThe.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_MaThe.Enabled = false;
            this.txt_MaThe.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.txt_MaThe.Location = new System.Drawing.Point(664, 19);
            this.txt_MaThe.Margin = new System.Windows.Forms.Padding(2);
            this.txt_MaThe.Name = "txt_MaThe";
            this.txt_MaThe.Size = new System.Drawing.Size(218, 27);
            this.txt_MaThe.TabIndex = 121;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(535, 139);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(111, 18);
            this.label6.TabIndex = 120;
            this.label6.Text = "Ngày hết hạn:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(535, 101);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 18);
            this.label3.TabIndex = 119;
            this.label3.Text = "Ngày đăng ký:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(535, 62);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 18);
            this.label2.TabIndex = 118;
            this.label2.Text = "Tình trạng:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(535, 22);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 18);
            this.label1.TabIndex = 117;
            this.label1.Text = "Mã thẻ:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel1.Controls.Add(this.txt_TimKiem);
            this.panel1.Controls.Add(this.cbo_TimKiem);
            this.panel1.Location = new System.Drawing.Point(2, 110);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(976, 40);
            this.panel1.TabIndex = 26;
            // 
            // txt_TimKiem
            // 
            this.txt_TimKiem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TimKiem.Location = new System.Drawing.Point(229, 11);
            this.txt_TimKiem.Margin = new System.Windows.Forms.Padding(2);
            this.txt_TimKiem.Name = "txt_TimKiem";
            this.txt_TimKiem.Size = new System.Drawing.Size(733, 23);
            this.txt_TimKiem.TabIndex = 1;
            this.txt_TimKiem.Text = "Từ Khóa";
            // 
            // cbo_TimKiem
            // 
            this.cbo_TimKiem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbo_TimKiem.FormattingEnabled = true;
            this.cbo_TimKiem.Items.AddRange(new object[] {
            "Mã độc giả",
            "Họ tên",
            "Ngày sinh",
            "Số điện thoại",
            "Email",
            "Địa chỉ",
            "Loại độc giả",
            "Giới tính"});
            this.cbo_TimKiem.Location = new System.Drawing.Point(20, 9);
            this.cbo_TimKiem.Margin = new System.Windows.Forms.Padding(2);
            this.cbo_TimKiem.Name = "cbo_TimKiem";
            this.cbo_TimKiem.Size = new System.Drawing.Size(198, 24);
            this.cbo_TimKiem.TabIndex = 0;
            this.cbo_TimKiem.SelectedIndexChanged += new System.EventHandler(this.cbo_TimKiem_SelectedIndexChanged);
            // 
            // lb_Ketquatimkiem
            // 
            this.lb_Ketquatimkiem.AutoSize = true;
            this.lb_Ketquatimkiem.BackColor = System.Drawing.Color.White;
            this.lb_Ketquatimkiem.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Ketquatimkiem.ForeColor = System.Drawing.Color.DodgerBlue;
            this.lb_Ketquatimkiem.Location = new System.Drawing.Point(2, 162);
            this.lb_Ketquatimkiem.Name = "lb_Ketquatimkiem";
            this.lb_Ketquatimkiem.Size = new System.Drawing.Size(199, 18);
            this.lb_Ketquatimkiem.TabIndex = 22;
            this.lb_Ketquatimkiem.Text = "Tìm được tất cả 0 kết quả";
            // 
            // btn_Search
            // 
            this.btn_Search.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_Search.Image = ((System.Drawing.Image)(resources.GetObject("btn_Search.Image")));
            this.btn_Search.Location = new System.Drawing.Point(1066, 110);
            this.btn_Search.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Search.Name = "btn_Search";
            this.btn_Search.Size = new System.Drawing.Size(80, 41);
            this.btn_Search.TabIndex = 24;
            this.btn_Search.UseVisualStyleBackColor = false;
            this.btn_Search.Click += new System.EventHandler(this.btn_Search_Click);
            // 
            // txt_LoaiDG
            // 
            this.txt_LoaiDG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_LoaiDG.Enabled = false;
            this.txt_LoaiDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.txt_LoaiDG.Location = new System.Drawing.Point(291, 170);
            this.txt_LoaiDG.Margin = new System.Windows.Forms.Padding(2);
            this.txt_LoaiDG.Name = "txt_LoaiDG";
            this.txt_LoaiDG.Size = new System.Drawing.Size(220, 27);
            this.txt_LoaiDG.TabIndex = 116;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel2.Controls.Add(this.lsvt_DSDG);
            this.panel2.Location = new System.Drawing.Point(2, 167);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1253, 278);
            this.panel2.TabIndex = 23;
            // 
            // panel
            // 
            this.panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel.Controls.Add(this.txt_NgaySinh);
            this.panel.Controls.Add(this.btn_InThe);
            this.panel.Controls.Add(this.buttonLichSuThe);
            this.panel.Controls.Add(this.txt_NgayHetHan);
            this.panel.Controls.Add(this.txt_NgayDK);
            this.panel.Controls.Add(this.txt_TinhTrang);
            this.panel.Controls.Add(this.txt_MaThe);
            this.panel.Controls.Add(this.label6);
            this.panel.Controls.Add(this.label3);
            this.panel.Controls.Add(this.label2);
            this.panel.Controls.Add(this.label1);
            this.panel.Controls.Add(this.txt_LoaiDG);
            this.panel.Controls.Add(this.txt_Email);
            this.panel.Controls.Add(this.label9);
            this.panel.Controls.Add(this.label12);
            this.panel.Controls.Add(this.txt_SoDienThoai);
            this.panel.Controls.Add(this.txt_TenDayDu);
            this.panel.Controls.Add(this.label8);
            this.panel.Controls.Add(this.label5);
            this.panel.Controls.Add(this.label4);
            this.panel.Location = new System.Drawing.Point(2, 448);
            this.panel.Margin = new System.Windows.Forms.Padding(2);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(1253, 228);
            this.panel.TabIndex = 22;
            // 
            // txt_Email
            // 
            this.txt_Email.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Email.Enabled = false;
            this.txt_Email.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.txt_Email.Location = new System.Drawing.Point(292, 132);
            this.txt_Email.Margin = new System.Windows.Forms.Padding(2);
            this.txt_Email.Name = "txt_Email";
            this.txt_Email.Size = new System.Drawing.Size(219, 27);
            this.txt_Email.TabIndex = 106;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(170, 136);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(71, 18);
            this.label9.TabIndex = 103;
            this.label9.Text = "Giới tính";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(169, 173);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(105, 18);
            this.label12.TabIndex = 95;
            this.label12.Text = "Loại độc giả:";
            // 
            // txt_SoDienThoai
            // 
            this.txt_SoDienThoai.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_SoDienThoai.Enabled = false;
            this.txt_SoDienThoai.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.txt_SoDienThoai.Location = new System.Drawing.Point(292, 94);
            this.txt_SoDienThoai.Margin = new System.Windows.Forms.Padding(2);
            this.txt_SoDienThoai.Name = "txt_SoDienThoai";
            this.txt_SoDienThoai.Size = new System.Drawing.Size(218, 27);
            this.txt_SoDienThoai.TabIndex = 92;
            // 
            // txt_TenDayDu
            // 
            this.txt_TenDayDu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_TenDayDu.Enabled = false;
            this.txt_TenDayDu.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.txt_TenDayDu.Location = new System.Drawing.Point(292, 19);
            this.txt_TenDayDu.Margin = new System.Windows.Forms.Padding(2);
            this.txt_TenDayDu.Name = "txt_TenDayDu";
            this.txt_TenDayDu.Size = new System.Drawing.Size(218, 27);
            this.txt_TenDayDu.TabIndex = 90;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(169, 101);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(112, 18);
            this.label8.TabIndex = 62;
            this.label8.Text = "Số điện thoại:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(170, 55);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 18);
            this.label5.TabIndex = 60;
            this.label5.Text = "Ngày sinh:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(170, 19);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 18);
            this.label4.TabIndex = 59;
            this.label4.Text = "Tên đầy đủ:";
            // 
            // btn_Refesh
            // 
            this.btn_Refesh.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_Refesh.Image = ((System.Drawing.Image)(resources.GetObject("btn_Refesh.Image")));
            this.btn_Refesh.Location = new System.Drawing.Point(982, 110);
            this.btn_Refesh.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Refesh.Name = "btn_Refesh";
            this.btn_Refesh.Size = new System.Drawing.Size(79, 40);
            this.btn_Refesh.TabIndex = 27;
            this.btn_Refesh.UseVisualStyleBackColor = false;
            this.btn_Refesh.Click += new System.EventHandler(this.btn_Refesh_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.pictureBox1);
            this.panel3.Location = new System.Drawing.Point(2, 1);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1253, 106);
            this.panel3.TabIndex = 28;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label7.Location = new System.Drawing.Point(683, 48);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 26);
            this.label7.TabIndex = 2;
            this.label7.Text = "Thẻ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label10.Location = new System.Drawing.Point(683, 24);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(101, 26);
            this.label10.TabIndex = 1;
            this.label10.Text = "Quản lý ";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(538, 2);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(150, 102);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // QuanLyThe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1256, 678);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lb_Ketquatimkiem);
            this.Controls.Add(this.btn_Search);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btn_Refesh);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "QuanLyThe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý thẻ độc giả";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.QuanLyThe_FormClosing);
            this.Load += new System.EventHandler(this.QuanLyThe_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel.ResumeLayout(false);
            this.panel.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView lsvt_DSDG;
        private System.Windows.Forms.ColumnHeader maTheDG;
        private System.Windows.Forms.ColumnHeader MaDG;
        private System.Windows.Forms.ColumnHeader tinhTrang;
        private System.Windows.Forms.ColumnHeader ngayDangKy;
        private System.Windows.Forms.ColumnHeader ngayHetHan;
        private System.Windows.Forms.ColumnHeader HoTen;
        private System.Windows.Forms.ColumnHeader NgaySinh;
        private System.Windows.Forms.ColumnHeader GioiTinh;
        private System.Windows.Forms.ColumnHeader DiaChi;
        private System.Windows.Forms.ColumnHeader Email;
        private System.Windows.Forms.ColumnHeader SDT;
        private System.Windows.Forms.ColumnHeader TenLDG;
        private System.Windows.Forms.TextBox txt_NgaySinh;
        private System.Windows.Forms.Button btn_InThe;
        private System.Windows.Forms.Button buttonLichSuThe;
        private System.Windows.Forms.TextBox txt_NgayHetHan;
        private System.Windows.Forms.TextBox txt_NgayDK;
        private System.Windows.Forms.TextBox txt_TinhTrang;
        private System.Windows.Forms.TextBox txt_MaThe;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txt_TimKiem;
        private System.Windows.Forms.ComboBox cbo_TimKiem;
        private System.Windows.Forms.Label lb_Ketquatimkiem;
        private System.Windows.Forms.Button btn_Search;
        private System.Windows.Forms.TextBox txt_LoaiDG;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.TextBox txt_Email;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txt_SoDienThoai;
        private System.Windows.Forms.TextBox txt_TenDayDu;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_Refesh;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}