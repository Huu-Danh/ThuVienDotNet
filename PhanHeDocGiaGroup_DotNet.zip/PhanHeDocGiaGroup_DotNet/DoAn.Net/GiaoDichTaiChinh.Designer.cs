﻿
namespace DoAn.Net
{
    partial class GiaoDichTaiChinh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GiaoDichTaiChinh));
            this.button_MoThe = new System.Windows.Forms.Button();
            this.button_Thu = new System.Windows.Forms.Button();
            this.button_Den = new System.Windows.Forms.Button();
            this.button_Rut = new System.Windows.Forms.Button();
            this.button_Phat = new System.Windows.Forms.Button();
            this.button_Nap = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.listBoxDocGia = new System.Windows.Forms.ListBox();
            this.textBoxMaDG = new System.Windows.Forms.TextBox();
            this.dataGridViewGiaoDich = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pageSetupDialog1 = new System.Windows.Forms.PageSetupDialog();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewGiaoDich)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // button_MoThe
            // 
            this.button_MoThe.BackColor = System.Drawing.Color.LimeGreen;
            this.button_MoThe.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_MoThe.ForeColor = System.Drawing.Color.Snow;
            this.button_MoThe.Location = new System.Drawing.Point(535, 416);
            this.button_MoThe.Margin = new System.Windows.Forms.Padding(2);
            this.button_MoThe.Name = "button_MoThe";
            this.button_MoThe.Size = new System.Drawing.Size(130, 34);
            this.button_MoThe.TabIndex = 18;
            this.button_MoThe.Text = "Mở khóa thẻ";
            this.button_MoThe.UseVisualStyleBackColor = false;
            this.button_MoThe.Click += new System.EventHandler(this.button_MoThe_Click);
            // 
            // button_Thu
            // 
            this.button_Thu.BackColor = System.Drawing.Color.Blue;
            this.button_Thu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Thu.ForeColor = System.Drawing.Color.Snow;
            this.button_Thu.Location = new System.Drawing.Point(427, 415);
            this.button_Thu.Margin = new System.Windows.Forms.Padding(2);
            this.button_Thu.Name = "button_Thu";
            this.button_Thu.Size = new System.Drawing.Size(104, 34);
            this.button_Thu.TabIndex = 17;
            this.button_Thu.Text = "Thu phí";
            this.button_Thu.UseVisualStyleBackColor = false;
            this.button_Thu.Click += new System.EventHandler(this.button_Thu_Click);
            // 
            // button_Den
            // 
            this.button_Den.BackColor = System.Drawing.Color.SlateGray;
            this.button_Den.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Den.ForeColor = System.Drawing.Color.Snow;
            this.button_Den.Location = new System.Drawing.Point(322, 415);
            this.button_Den.Margin = new System.Windows.Forms.Padding(2);
            this.button_Den.Name = "button_Den";
            this.button_Den.Size = new System.Drawing.Size(100, 34);
            this.button_Den.TabIndex = 16;
            this.button_Den.Text = "Đền bù";
            this.button_Den.UseVisualStyleBackColor = false;
            this.button_Den.Click += new System.EventHandler(this.button_Den_Click);
            // 
            // button_Rut
            // 
            this.button_Rut.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.button_Rut.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Rut.ForeColor = System.Drawing.Color.Snow;
            this.button_Rut.Location = new System.Drawing.Point(218, 415);
            this.button_Rut.Margin = new System.Windows.Forms.Padding(2);
            this.button_Rut.Name = "button_Rut";
            this.button_Rut.Size = new System.Drawing.Size(100, 34);
            this.button_Rut.TabIndex = 15;
            this.button_Rut.Text = "Rút tiền";
            this.button_Rut.UseVisualStyleBackColor = false;
            this.button_Rut.Click += new System.EventHandler(this.button_Rut_Click);
            // 
            // button_Phat
            // 
            this.button_Phat.BackColor = System.Drawing.Color.OrangeRed;
            this.button_Phat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Phat.ForeColor = System.Drawing.Color.Snow;
            this.button_Phat.Location = new System.Drawing.Point(112, 416);
            this.button_Phat.Margin = new System.Windows.Forms.Padding(2);
            this.button_Phat.Name = "button_Phat";
            this.button_Phat.Size = new System.Drawing.Size(100, 34);
            this.button_Phat.TabIndex = 14;
            this.button_Phat.Text = "Bị phạt";
            this.button_Phat.UseVisualStyleBackColor = false;
            this.button_Phat.Click += new System.EventHandler(this.button_Phat_Click);
            // 
            // button_Nap
            // 
            this.button_Nap.BackColor = System.Drawing.Color.DarkOrange;
            this.button_Nap.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Nap.ForeColor = System.Drawing.Color.Snow;
            this.button_Nap.Location = new System.Drawing.Point(8, 416);
            this.button_Nap.Margin = new System.Windows.Forms.Padding(2);
            this.button_Nap.Name = "button_Nap";
            this.button_Nap.Size = new System.Drawing.Size(100, 34);
            this.button_Nap.TabIndex = 13;
            this.button_Nap.Text = "Nạp tiền";
            this.button_Nap.UseVisualStyleBackColor = false;
            this.button_Nap.Click += new System.EventHandler(this.button_Nap_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 151);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(148, 20);
            this.label1.TabIndex = 12;
            this.label1.Text = "Nhập mã độc giả:";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // listBoxDocGia
            // 
            this.listBoxDocGia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxDocGia.FormattingEnabled = true;
            this.listBoxDocGia.ItemHeight = 20;
            this.listBoxDocGia.Location = new System.Drawing.Point(9, 183);
            this.listBoxDocGia.Margin = new System.Windows.Forms.Padding(2);
            this.listBoxDocGia.Name = "listBoxDocGia";
            this.listBoxDocGia.Size = new System.Drawing.Size(679, 224);
            this.listBoxDocGia.TabIndex = 21;
            // 
            // textBoxMaDG
            // 
            this.textBoxMaDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMaDG.ForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxMaDG.Location = new System.Drawing.Point(175, 151);
            this.textBoxMaDG.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxMaDG.Name = "textBoxMaDG";
            this.textBoxMaDG.Size = new System.Drawing.Size(513, 26);
            this.textBoxMaDG.TabIndex = 20;
            this.textBoxMaDG.TextChanged += new System.EventHandler(this.textBoxMaDG_TextChanged);
            // 
            // dataGridViewGiaoDich
            // 
            this.dataGridViewGiaoDich.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewGiaoDich.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewGiaoDich.Location = new System.Drawing.Point(8, 453);
            this.dataGridViewGiaoDich.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridViewGiaoDich.Name = "dataGridViewGiaoDich";
            this.dataGridViewGiaoDich.RowHeadersWidth = 51;
            this.dataGridViewGiaoDich.RowTemplate.Height = 24;
            this.dataGridViewGiaoDich.Size = new System.Drawing.Size(679, 258);
            this.dataGridViewGiaoDich.TabIndex = 19;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(13, 8);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(674, 135);
            this.panel1.TabIndex = 22;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(376, 8);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(181, 45);
            this.label2.TabIndex = 2;
            this.label2.Text = "Giao dịch";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(175, 8);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(219, 121);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // GiaoDichTaiChinh
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(694, 717);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button_MoThe);
            this.Controls.Add(this.button_Thu);
            this.Controls.Add(this.button_Den);
            this.Controls.Add(this.button_Rut);
            this.Controls.Add(this.button_Phat);
            this.Controls.Add(this.button_Nap);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBoxDocGia);
            this.Controls.Add(this.textBoxMaDG);
            this.Controls.Add(this.dataGridViewGiaoDich);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "GiaoDichTaiChinh";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GiaoDichTaiChinh";
            this.Load += new System.EventHandler(this.GiaoDichTaiChinh_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewGiaoDich)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_MoThe;
        private System.Windows.Forms.Button button_Thu;
        private System.Windows.Forms.Button button_Den;
        private System.Windows.Forms.Button button_Rut;
        private System.Windows.Forms.Button button_Phat;
        private System.Windows.Forms.Button button_Nap;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ListBox listBoxDocGia;
        private System.Windows.Forms.TextBox textBoxMaDG;
        private System.Windows.Forms.DataGridView dataGridViewGiaoDich;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PageSetupDialog pageSetupDialog1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}