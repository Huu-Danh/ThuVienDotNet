﻿
namespace DoAn.Net
{
    partial class From_DangKy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(From_DangKy));
            this.label1 = new System.Windows.Forms.Label();
            this.rdo_Nu = new System.Windows.Forms.RadioButton();
            this.rdo_Nam = new System.Windows.Forms.RadioButton();
            this.label19 = new System.Windows.Forms.Label();
            this.btn_Add = new System.Windows.Forms.Button();
            this.btn_Save = new System.Windows.Forms.Button();
            this.txt_DiaChi = new System.Windows.Forms.TextBox();
            this.txt_Fax = new System.Windows.Forms.TextBox();
            this.txt_Lop = new System.Windows.Forms.TextBox();
            this.txt_Khoa = new System.Windows.Forms.TextBox();
            this.txt_Email = new System.Windows.Forms.TextBox();
            this.txt_SoDienThoai = new System.Windows.Forms.TextBox();
            this.txt_BoPhan = new System.Windows.Forms.TextBox();
            this.txt_TenDayDu = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_DatMacDinh = new System.Windows.Forms.Button();
            this.pB_User = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.dt_NgaySinh = new System.Windows.Forms.DateTimePicker();
            this.cbo_LoaiDG = new System.Windows.Forms.ComboBox();
            this.txt_ChuyenMon = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.errorSDT = new System.Windows.Forms.ErrorProvider(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.insertNhieuDocGia = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pB_User)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorSDT)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(247, 519);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 18);
            this.label1.TabIndex = 88;
            this.label1.Text = "Địa chỉ";
            // 
            // rdo_Nu
            // 
            this.rdo_Nu.AutoSize = true;
            this.rdo_Nu.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdo_Nu.Location = new System.Drawing.Point(1096, 241);
            this.rdo_Nu.Name = "rdo_Nu";
            this.rdo_Nu.Size = new System.Drawing.Size(45, 22);
            this.rdo_Nu.TabIndex = 87;
            this.rdo_Nu.TabStop = true;
            this.rdo_Nu.Text = "Nữ";
            this.rdo_Nu.UseVisualStyleBackColor = true;
            // 
            // rdo_Nam
            // 
            this.rdo_Nam.AutoSize = true;
            this.rdo_Nam.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdo_Nam.Location = new System.Drawing.Point(930, 236);
            this.rdo_Nam.Name = "rdo_Nam";
            this.rdo_Nam.Size = new System.Drawing.Size(58, 22);
            this.rdo_Nam.TabIndex = 86;
            this.rdo_Nam.TabStop = true;
            this.rdo_Nam.Text = "Nam";
            this.rdo_Nam.UseVisualStyleBackColor = true;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.White;
            this.label19.ForeColor = System.Drawing.Color.Red;
            this.label19.Location = new System.Drawing.Point(400, 175);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(11, 13);
            this.label19.TabIndex = 84;
            this.label19.Text = "*";
            // 
            // btn_Add
            // 
            this.btn_Add.AutoSize = true;
            this.btn_Add.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_Add.BackColor = System.Drawing.Color.Transparent;
            this.btn_Add.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_Add.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Add.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Add.Image = ((System.Drawing.Image)(resources.GetObject("btn_Add.Image")));
            this.btn_Add.Location = new System.Drawing.Point(24, 22);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(30, 30);
            this.btn_Add.TabIndex = 83;
            this.btn_Add.UseVisualStyleBackColor = false;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // btn_Save
            // 
            this.btn_Save.AutoSize = true;
            this.btn_Save.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_Save.BackColor = System.Drawing.Color.Transparent;
            this.btn_Save.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.Image = ((System.Drawing.Image)(resources.GetObject("btn_Save.Image")));
            this.btn_Save.Location = new System.Drawing.Point(78, 22);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(30, 30);
            this.btn_Save.TabIndex = 82;
            this.btn_Save.UseVisualStyleBackColor = false;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // txt_DiaChi
            // 
            this.txt_DiaChi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_DiaChi.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.txt_DiaChi.Location = new System.Drawing.Point(429, 515);
            this.txt_DiaChi.Name = "txt_DiaChi";
            this.txt_DiaChi.Size = new System.Drawing.Size(841, 27);
            this.txt_DiaChi.TabIndex = 80;
            // 
            // txt_Fax
            // 
            this.txt_Fax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Fax.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.txt_Fax.Location = new System.Drawing.Point(431, 455);
            this.txt_Fax.Name = "txt_Fax";
            this.txt_Fax.Size = new System.Drawing.Size(325, 27);
            this.txt_Fax.TabIndex = 79;
            // 
            // txt_Lop
            // 
            this.txt_Lop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Lop.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.txt_Lop.Location = new System.Drawing.Point(897, 341);
            this.txt_Lop.Name = "txt_Lop";
            this.txt_Lop.Size = new System.Drawing.Size(328, 27);
            this.txt_Lop.TabIndex = 78;
            // 
            // txt_Khoa
            // 
            this.txt_Khoa.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Khoa.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.txt_Khoa.Location = new System.Drawing.Point(897, 293);
            this.txt_Khoa.Name = "txt_Khoa";
            this.txt_Khoa.Size = new System.Drawing.Size(328, 27);
            this.txt_Khoa.TabIndex = 77;
            // 
            // txt_Email
            // 
            this.txt_Email.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Email.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.txt_Email.Location = new System.Drawing.Point(431, 401);
            this.txt_Email.Name = "txt_Email";
            this.txt_Email.Size = new System.Drawing.Size(325, 27);
            this.txt_Email.TabIndex = 73;
            // 
            // txt_SoDienThoai
            // 
            this.txt_SoDienThoai.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_SoDienThoai.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.txt_SoDienThoai.Location = new System.Drawing.Point(431, 345);
            this.txt_SoDienThoai.Name = "txt_SoDienThoai";
            this.txt_SoDienThoai.Size = new System.Drawing.Size(325, 27);
            this.txt_SoDienThoai.TabIndex = 72;
            this.txt_SoDienThoai.TextChanged += new System.EventHandler(this.txt_SoDienThoai_TextChanged);
            // 
            // txt_BoPhan
            // 
            this.txt_BoPhan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_BoPhan.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.txt_BoPhan.Location = new System.Drawing.Point(897, 179);
            this.txt_BoPhan.Name = "txt_BoPhan";
            this.txt_BoPhan.Size = new System.Drawing.Size(328, 27);
            this.txt_BoPhan.TabIndex = 71;
            // 
            // txt_TenDayDu
            // 
            this.txt_TenDayDu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_TenDayDu.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.txt_TenDayDu.Location = new System.Drawing.Point(431, 178);
            this.txt_TenDayDu.Name = "txt_TenDayDu";
            this.txt_TenDayDu.Size = new System.Drawing.Size(325, 27);
            this.txt_TenDayDu.TabIndex = 68;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(249, 463);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 18);
            this.label17.TabIndex = 67;
            this.label17.Text = "Fax";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(786, 353);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(36, 18);
            this.label16.TabIndex = 66;
            this.label16.Text = "Lớp";
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(786, 297);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(47, 18);
            this.label15.TabIndex = 65;
            this.label15.Text = "Khóa";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(786, 238);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(71, 18);
            this.label14.TabIndex = 64;
            this.label14.Text = "Giới tính";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(249, 283);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(100, 18);
            this.label12.TabIndex = 62;
            this.label12.Text = "Loại độc giả";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(256, 345);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(107, 18);
            this.label8.TabIndex = 58;
            this.label8.Text = "Số điện thoại";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(785, 183);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 18);
            this.label7.TabIndex = 57;
            this.label7.Text = "Bộ phận";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(249, 238);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 18);
            this.label5.TabIndex = 55;
            this.label5.Text = "Ngày sinh";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(256, 183);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 18);
            this.label4.TabIndex = 54;
            this.label4.Text = "Tên đầy đủ ";
            // 
            // btn_DatMacDinh
            // 
            this.btn_DatMacDinh.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_DatMacDinh.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_DatMacDinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_DatMacDinh.Image = ((System.Drawing.Image)(resources.GetObject("btn_DatMacDinh.Image")));
            this.btn_DatMacDinh.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_DatMacDinh.Location = new System.Drawing.Point(17, 426);
            this.btn_DatMacDinh.Name = "btn_DatMacDinh";
            this.btn_DatMacDinh.Size = new System.Drawing.Size(212, 43);
            this.btn_DatMacDinh.TabIndex = 52;
            this.btn_DatMacDinh.Text = "Đặt mặc định";
            this.btn_DatMacDinh.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_DatMacDinh.UseVisualStyleBackColor = true;
            // 
            // pB_User
            // 
            this.pB_User.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pB_User.Image = ((System.Drawing.Image)(resources.GetObject("pB_User.Image")));
            this.pB_User.Location = new System.Drawing.Point(17, 191);
            this.pB_User.Name = "pB_User";
            this.pB_User.Size = new System.Drawing.Size(212, 216);
            this.pB_User.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pB_User.TabIndex = 51;
            this.pB_User.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(248, 409);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(50, 18);
            this.label9.TabIndex = 59;
            this.label9.Text = "Email";
            // 
            // dt_NgaySinh
            // 
            this.dt_NgaySinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dt_NgaySinh.Location = new System.Drawing.Point(431, 241);
            this.dt_NgaySinh.Name = "dt_NgaySinh";
            this.dt_NgaySinh.Size = new System.Drawing.Size(325, 23);
            this.dt_NgaySinh.TabIndex = 89;
            // 
            // cbo_LoaiDG
            // 
            this.cbo_LoaiDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbo_LoaiDG.FormattingEnabled = true;
            this.cbo_LoaiDG.Location = new System.Drawing.Point(431, 288);
            this.cbo_LoaiDG.Name = "cbo_LoaiDG";
            this.cbo_LoaiDG.Size = new System.Drawing.Size(325, 28);
            this.cbo_LoaiDG.TabIndex = 90;
            this.cbo_LoaiDG.SelectedIndexChanged += new System.EventHandler(this.cbo_LoaiDG_SelectedIndexChanged);
            // 
            // txt_ChuyenMon
            // 
            this.txt_ChuyenMon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ChuyenMon.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.txt_ChuyenMon.Location = new System.Drawing.Point(897, 406);
            this.txt_ChuyenMon.Name = "txt_ChuyenMon";
            this.txt_ChuyenMon.Size = new System.Drawing.Size(328, 27);
            this.txt_ChuyenMon.TabIndex = 92;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(762, 410);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 18);
            this.label2.TabIndex = 91;
            this.label2.Text = "Chuyên môn";
            // 
            // errorSDT
            // 
            this.errorSDT.ContainerControl = this;
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.panel1.Controls.Add(this.insertNhieuDocGia);
            this.panel1.Controls.Add(this.btn_Save);
            this.panel1.Controls.Add(this.btn_Add);
            this.panel1.ImeMode = System.Windows.Forms.ImeMode.On;
            this.panel1.Location = new System.Drawing.Point(-4, 588);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1306, 77);
            this.panel1.TabIndex = 93;
            // 
            // insertNhieuDocGia
            // 
            this.insertNhieuDocGia.Image = global::DoAn.Net.Properties.Resources.icons8_insert_16;
            this.insertNhieuDocGia.Location = new System.Drawing.Point(139, 25);
            this.insertNhieuDocGia.Name = "insertNhieuDocGia";
            this.insertNhieuDocGia.Size = new System.Drawing.Size(53, 30);
            this.insertNhieuDocGia.TabIndex = 84;
            this.insertNhieuDocGia.UseVisualStyleBackColor = true;
            this.insertNhieuDocGia.Click += new System.EventHandler(this.insertNhieuDocGia_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Narrow", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label6.Location = new System.Drawing.Point(578, 46);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(266, 37);
            this.label6.TabIndex = 95;
            this.label6.Text = "ĐĂNG KÝ ĐỘC GIẢ";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Location = new System.Drawing.Point(-4, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1306, 150);
            this.panel2.TabIndex = 96;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(470, 14);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(127, 125);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // From_DangKy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1302, 659);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txt_ChuyenMon);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cbo_LoaiDG);
            this.Controls.Add(this.dt_NgaySinh);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rdo_Nu);
            this.Controls.Add(this.rdo_Nam);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.txt_DiaChi);
            this.Controls.Add(this.txt_Fax);
            this.Controls.Add(this.txt_Lop);
            this.Controls.Add(this.txt_Khoa);
            this.Controls.Add(this.txt_Email);
            this.Controls.Add(this.txt_SoDienThoai);
            this.Controls.Add(this.txt_BoPhan);
            this.Controls.Add(this.txt_TenDayDu);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btn_DatMacDinh);
            this.Controls.Add(this.pB_User);
            this.Controls.Add(this.label9);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.Name = "From_DangKy";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Đăng ký độc giả";
            this.Load += new System.EventHandler(this.From_DangKy_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pB_User)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorSDT)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rdo_Nu;
        private System.Windows.Forms.RadioButton rdo_Nam;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.TextBox txt_DiaChi;
        private System.Windows.Forms.TextBox txt_Fax;
        private System.Windows.Forms.TextBox txt_Lop;
        private System.Windows.Forms.TextBox txt_Khoa;
        private System.Windows.Forms.TextBox txt_Email;
        private System.Windows.Forms.TextBox txt_SoDienThoai;
        private System.Windows.Forms.TextBox txt_BoPhan;
        private System.Windows.Forms.TextBox txt_TenDayDu;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_DatMacDinh;
        private System.Windows.Forms.PictureBox pB_User;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker dt_NgaySinh;
        private System.Windows.Forms.ComboBox cbo_LoaiDG;
        private System.Windows.Forms.TextBox txt_ChuyenMon;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ErrorProvider errorSDT;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button insertNhieuDocGia;
    }
}

